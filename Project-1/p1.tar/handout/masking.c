#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int main(){

    int x = 5408;
    x =  x >> 1;
    printf("%d", x);

   
}