#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "scheduler.h"
#include "clock.h"
#include "structs.h"
#include "constants.h"

int main() {
  Schedule * test = scheduler_init();
  return 0;

}