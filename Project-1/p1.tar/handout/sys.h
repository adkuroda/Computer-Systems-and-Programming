/* Do Not Modify this File */

#ifndef GRADING_SYS_H
#define GRADING_SYS_H

/* Shared Function Prototypes */
void sys_init(FILE *fp);
void sys_run();

#endif /* GRADING_SYS_H */
